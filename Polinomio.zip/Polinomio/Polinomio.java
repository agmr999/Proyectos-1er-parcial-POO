import java.util.ArrayList;
import java.util.Iterator;

import com.sun.glass.ui.Robot;
import com.sun.javafx.geom.AreaOp.SubOp;
import com.sun.org.apache.xpath.internal.operations.Div;

public class Polinomio{
    private ArrayList<Monomio> terminos;

    public Polinomio(){
        terminos = new ArrayList<Monomio>();
    }

    public void add(Monomio mono){
        terminos.add(mono);
    }

    public void imprimir(){
        for(Monomio t : terminos){
            System.out.print(t);
        }
    }

    public void reducir(){
        ArrayList<Monomio>aux = new ArrayList<>();
        while(terminos.size()>0){
            Monomio actual = terminos.remove(0);
            int contador = 0;
            while(contador < terminos.size()){
                Monomio t = terminos.get(contador);
                if(actual.isSemejante(t)){
                actual.setCoeficiente(actual.getCoeficiente()+t.getCoeficiente());
                terminos.remove(contador);
                }else{
                    contador++;
                }
            }
            if(actual.getCoeficiente()!=0){
                aux.add(actual);
            }
        }
        terminos = aux;
    }



    public void ordenar(){
        Polinomio prueba = new Polinomio();
        for(int x=0;x<this.terminos.size();x++){
            prueba.add(this.terminos.get(x));
        }
        float a=0;
        int mayor=0;
        for(int x=this.terminos.size()-1;x>=0;x--){
            for(int y=0;y<prueba.terminos.size();y++){
                if(prueba.terminos.get(y).getExponente()>a){
                    a=prueba.terminos.get(y).getExponente();
                    mayor=y;
                }
            }
            this.terminos.set(x, prueba.terminos.get(mayor));
            prueba.terminos.remove(mayor);
            a=0;
        }
    }

    public void ordenar2(){
        Polinomio prueba = new Polinomio();
        for(int x=0;x<this.terminos.size();x++){
            prueba.add(this.terminos.get(x));
        }
        float a=0;
        int mayor=0;
        for(int x=0;x<this.terminos.size();x++){
            for(int y=0;y<prueba.terminos.size();y++){
                if(prueba.terminos.get(y).getExponente()>a){
                    a=prueba.terminos.get(y).getExponente();
                    mayor=y;
                }
            }
            this.terminos.set(x, prueba.terminos.get(mayor));
            prueba.terminos.remove(mayor);
            a=0;
        }
    }


    public static Polinomio sumapol(Polinomio po1,Polinomio po2){
        Polinomio Resultado = new Polinomio();
        Polinomio prueba = new Polinomio();
        for(int y=0; y<po2.terminos.size();y++){
            prueba.add(po2.terminos.get(y));
        }
        float res;
        int acc=0;
        for(int x=0;x<po1.terminos.size();x++){
            for(int y=0; y<prueba.terminos.size();y++){
                if(po1.terminos.get(x).getExponente()==prueba.terminos.get(y).getExponente()){
                    res=(po1.terminos.get(x).getCoeficiente())+(prueba.terminos.get(y).getCoeficiente());
                    Resultado.add(new Monomio(res, po1.terminos.get(x).getExponente()));
                    acc=1;
                    //System.out.println(res);
                    prueba.terminos.remove(y);
                }
        }
        if(acc==0){
        Resultado.add(po1.terminos.get(x));
        }
            acc=0;
    }
    for(int y=0; y<prueba.terminos.size();y++){
        Resultado.add(prueba.terminos.get(y));
    }
    return Resultado;
}

public static Polinomio restapol(Polinomio po1,Polinomio po2){
    Polinomio Resultado = new Polinomio();
    Polinomio prueba = new Polinomio();
    for(int y=0; y<po2.terminos.size();y++){
        prueba.add(po2.terminos.get(y));
    }
    float res;
    int acc=0;
    for(int x=0;x<po1.terminos.size();x++){
        for(int y=0; y<prueba.terminos.size();y++){
            if(po1.terminos.get(x).getExponente()==prueba.terminos.get(y).getExponente()){
                res=(po1.terminos.get(x).getCoeficiente())-(prueba.terminos.get(y).getCoeficiente());
                Resultado.add(new Monomio(res, po1.terminos.get(x).getExponente()));
                acc=1;
                //System.out.println(res);
                prueba.terminos.remove(y);
            }
    }
    if(acc==0){
    Resultado.add(po1.terminos.get(x));
    }
        acc=0;
}
for(int y=0; y<prueba.terminos.size();y++){
    float coe = 0-prueba.terminos.get(y).getCoeficiente();
    Resultado.add(new Monomio(coe, prueba.terminos.get(y).getExponente()));
}
return Resultado;
}

public static Polinomio multiplicacion(Polinomio po1, Polinomio po2){
    Polinomio Resultado = new Polinomio();
    float coe;
    int exp;
    for(int x=0; x<po1.terminos.size();x++){
        for(int y=0; y<po2.terminos.size(); y++){
            coe=po1.terminos.get(x).getCoeficiente()*po2.terminos.get(y).getCoeficiente();
            exp=po1.terminos.get(x).getExponente()+po2.terminos.get(y).getExponente();
            Resultado.add(new Monomio(coe,exp));
        }
    }
    Resultado.reducir();
    return Resultado;
}


public static void prueba(Polinomio po1,Polinomio po2){
    Polinomio Resultado = new Polinomio();
    Polinomio Div = new Polinomio();
    for(int y=0; y<po2.terminos.size();y++){
        Div.add(po2.terminos.get(y));
    }
    Div.ordenar2(); 
    do{
        po1.ordenar2();  
        float nexcoef = Div.terminos.get(0).getCoeficiente()/po1.terminos.get(0).getCoeficiente();
        int newexp = Div.terminos.get(0).getExponente()-po1.terminos.get(0).getExponente();
        Monomio Multi = new Monomio(nexcoef, newexp);
        Resultado.add(Multi);
        for(int x=0; x<po1.terminos.size(); x++){
            float nexcoef2 = nexcoef*po1.terminos.get(x).getCoeficiente()*(-1);
            int newexp2 = newexp+po1.terminos.get(x).getExponente();
            Multi = new Monomio(nexcoef2, newexp2);
            Div.add(Multi);
        }
        Div.reducir();
        Div.ordenar2();
}while(po1.terminos.get(0).getExponente()<=Div.terminos.get(0).getExponente()); 
    Resultado.imprimir();
}

}