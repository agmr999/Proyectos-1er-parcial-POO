import com.sun.org.apache.xpath.internal.SourceTree;

//import com.oracle.xmlns.internal.webservices.jaxws_databinding.SoapBindingParameterStyle;

//import javafx.scene.effect.Light.Spot;

public class Principal {

    public static void main(String[] args) {    
        Polinomio polino = new Polinomio();
        Polinomio polino2 = new Polinomio();
        Polinomio Resul = new Polinomio();
        Polinomio Resul2 = new Polinomio();
        Polinomio Multi = new Polinomio();
        
        polino.add(new Monomio(-2,2));
        polino.add(new Monomio(4,3));
        polino.add(new Monomio(6,2));
        polino.add(new Monomio(12,3));
        polino2.add(new Monomio(5,4));
        polino2.add(new Monomio(-5,3));
        polino2.add(new Monomio(6,2));
        polino2.add(new Monomio(-4,3));
        //polino.imprimir();
        //System.out.println("");
        polino.reducir();
        polino.imprimir();
        System.out.println("");
        polino2.reducir();
        polino2.imprimir();
        System.out.println("\nSuma");
        Resul = Polinomio.sumapol(polino, polino2);
        Resul.imprimir();
        System.out.println("\nResta");
        Resul2 = Polinomio.restapol(polino, polino2);
        Resul2.imprimir();
        System.out.println("\nMultiplicacion:");
        Multi = Polinomio.multiplicacion(polino, polino2);
        Multi.ordenar();
        Multi.imprimir();
        System.out.println("\nDivision:");
        Polinomio.prueba(polino, polino2);
    }

}