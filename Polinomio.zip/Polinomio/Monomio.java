public class Monomio {
    private float coeficiente;
    private int exponente;
    //constantes por politica deben ser en mayusculas
    public static final char VARIABLE='x';
    //contructor
    public Monomio(float coeficiente, int exponente){
        this.coeficiente=coeficiente;
        this.exponente=exponente;
    }
    //set y get
    
    public String toString(){
        //return String.format("%c%d%c^%d ", (coeficiente>0?'+':' '),coeficiente,VARIABLE,exponente);
        if(coeficiente>0){
            return String.format("+%f%c^%d ",coeficiente,VARIABLE,exponente);
        }else{
            return String.format("%f%c^%d ",coeficiente,VARIABLE,exponente);
        }
        
    }

    /**
     * @return the coeficiente
     */
    public float getCoeficiente() {
        return coeficiente;
    }

    /**
     * @param coeficiente the coeficiente to set
     */
    public void setCoeficiente(float coeficiente) {
        this.coeficiente = coeficiente;
    }

    /**
     * @return the exponente
     */
    public int getExponente() {
        return exponente;
    }

    /**
     * @param exponente the exponente to set
     */
    public void setExponente(int exponente) {
        this.exponente = exponente;
    }
    public boolean isSemejante(Monomio otro){
        return this.getExponente() == otro.getExponente();
    }

   /* public static Monomio sumaMonomio(Monomio mo1,Monomio mo2){
        mo1.coeficiente=mo1.coeficiente+mo2.getCoeficiente();
        return mo1;
    }*/
}