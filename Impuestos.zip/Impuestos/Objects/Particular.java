public class Particular extends Pasajero{

    public Particular(String placa, String noSerie, String marca, Integer modelo, Double valorFactura, Integer noPasajeros){
        super(placa, noSerie, marca, modelo, valorFactura, noPasajeros);
    }

}