public abstract class Pasajero extends Vehiculo{

    private Integer noPasajeros;

    public Pasajero(String placa, String noSerie, String marca, Integer modelo, Double valorFactura, Integer noPasajeros){
        super(placa,noSerie,marca,modelo,valorFactura);
        this.noPasajeros=noPasajeros;
    }

    /**
     * @return the noPasajeros
     */
    public Integer getNoPasajeros() {
        return noPasajeros;
    }

    /**
     * @param noPasajeros the noPasajeros to set
     */
    public void setNoPasajeros(Integer noPasajeros) {
        this.noPasajeros = noPasajeros;
    }

    @Override
    public Double calcularTenencia(){
        return this.getValorFactura()*calcularGravable();
    }

}