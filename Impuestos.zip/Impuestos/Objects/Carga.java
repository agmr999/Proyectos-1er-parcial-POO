public abstract class Carga extends Vehiculo{

    private Integer toneladas;
    private Boolean publico;

    public Carga(String placa, String noSerie, String marca, Integer modelo, Double valorFactura, Integer toneladas, Boolean publico){
        super(placa, noSerie, marca, modelo, valorFactura);
        this.toneladas=toneladas;
        this.publico=publico;
    }

    /**
     * @return the toneladas
     */
    public Integer getToneladas() {
        return toneladas;
    }

    /**
     * @return the publico
     */
    public Boolean getPublico() {
        return publico;
    }

    /**
     * @param toneladas the toneladas to set
     */
    public void setToneladas(Integer toneladas) {
        this.toneladas = toneladas;
    }

    /**
     * @param publico the publico to set
     */
    public void setPublico(Boolean publico) {
        this.publico = publico;
    }

    @Override
    public Float calcularGravable(){
        if(!this.publico){
            return super.calcularGravable();
        }
        else{
            return this.getModelo()>=2009 ? 0.03 : 0.01;
        }
    }

    @Override
    public Double calcularTenencia(){
        return this.getValorFactura()*(1+this.toneladas/10.0);
    }
    
}