public class Camioneta extends Carga{

    public Camioneta(String placa, String noSerie, String marca, Integer modelo, Double valorFactura, Integer toneladas, Boolean publico){
        super(placa, noSerie, marca, modelo, valorFactura, toneladas, publico);
    }
    
}