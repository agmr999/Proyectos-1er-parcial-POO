public class Impuestos {

    public static void main(String[] args) {
        ArrayList vehiculos = new ArrayList();
		Scanner Lee = new Scanner(System.in);
		int a;

                System.out.println("Vehiculo Particular\nIngresa la Placa, #Serie, Marca, Modelo, Factura, Pasajeros");
					vehiculos.add(new Particular(sc.next(),sc.next(),sc.next(),sc.nextInt(),sc.nextFloat(),sc.nextInt()));

                System.out.println("Taxi\nIngresa la Placa, #Serie, Marca, Modelo, Factura,Pasajeros, concesion");
					vehiculos.add(new Taxi(sc.next(), sc.next(), sc.next(), sc.nextInt(), sc.nextFloat(), sc.nextInt(), sc.nextInt()));

                System.out.println("Camioneta\nIngresa la Placa, #Serie, Marca, Modelo, Factura, toneladas y Publico (true o false)");
					vehiculos.add(new Camioneta(sc.next(), sc.next(), sc.next(), sc.nextInt(), sc.nextFloat(), sc.nextInt(), sc.nextBoolean()));

                System.out.println("Camion\nIngresa la Placa, #Serie, Marca, Modelo, Factura, toneladas, Publico (true o false), ejes");
					vehiculos.add(new Camion(sc.next(), sc.next(), sc.next(), sc.nextInt(), sc.nextFloat(), sc.nextInt(), sc.nextBoolean(), sc.nextInt()));

                System.out.println("Ver los vehiculos");
				for (Vehiculo vehiculo : vehiculos) {
					System.out.println(vehiculo.informacion());
				}
    }

}