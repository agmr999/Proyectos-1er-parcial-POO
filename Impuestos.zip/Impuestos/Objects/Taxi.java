public class Taxi extends Pasajero{

    private Integer aniosConcesion;

    public Taxi(String placa, String noSerie, String marca, Integer modelo, Double valorFactura, Integer noPasajeros, Integer aniosConcesion){
        super(placa, noSerie, marca, modelo, valorFactura, noPasajeros);
        this.aniosConcesion=aniosConcesion;
    }

    /**
     * @return the aniosConcesion
     */
    public Integer getAniosConcesion() {
        return aniosConcesion;
    }

    /**
     * @param aniosConcesion the aniosConcesion to set
     */
    public void setAniosConcesion(Integer aniosConcesion) {
        this.aniosConcesion = aniosConcesion;
    }

    @Override
    public Double calcularTenencia(){
        return super.calcularTenencia()*(1+ this.getNoPasajeros()/10.0);
    }

}