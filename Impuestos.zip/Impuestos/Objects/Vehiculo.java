public abstract class Vehiculo {

    private String placa;
    private String noSerie;
    private String marca;
    private Integer modelo;
    private Double valorFactura;

    public Vehiculo(String placa, String noSerie, String marca, Integer modelo, Double valorFactura){
        this.placa=placa;
        this.noSerie=noSerie;
        this.marca=marca;
        this.modelo=modelo;
        this.valorFactura=valorFactura;
    }

    @Override
	public boolean equals(Object Comp) {
		if(Comp instanceof Vehiculo) {
			Vehiculo NV = (Vehiculo)Comp;
			return (this.getPlaca() == NV.getPlaca()) && (this.getNoSerie() == NV.getNoSerie());
		}
		return false;
	}

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(Integer modelo) {
        this.modelo = modelo;
    }

    /**
     * @param noSerie the noSerie to set
     */
    public void setNoSerie(String noSerie) {
        this.noSerie = noSerie;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @param valorFactura the valorFactura to set
     */
    public void setValorFactura(Double valorFactura) {
        this.valorFactura = valorFactura;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @return the modelo
     */
    public Integer getModelo() {
        return modelo;
    }

    /**
     * @return the noSerie
     */
    public String getNoSerie() {
        return noSerie;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @return the valorFactura
     */
    public Double getValorFactura() {
        return valorFactura;
    }

    public abstract Double calcularTenencia();

    public Float calcularGravable(){
        return this.modelo >= 2009 ? 0.05 : 0.02;
    }

}