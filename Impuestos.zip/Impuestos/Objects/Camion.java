public class Camion extends Carga{

    private Integer ejes;

    public Camion(String placa, String noSerie, String marca, Integer modelo, Double valorFactura, Integer toneladas, Boolean publico, Integer ejes){
        super(placa, noSerie, marca, modelo, valorFactura, toneladas, publico);
        this.ejes=ejes;
    }

    @Override
    public Float calcularGravable(){
        return super.calcularGravable()*(1+ejes*0.01);
    }
    
}